import React ,{ Component } from 'react';
import './contactform.css';
import axios from 'axios';

class ContactForm extends Component{
state = {
  contact :{
    name:'',
    phone:'',
    email:'',
    message:'',

  }
}

onChangeHandler = (propertyName) => (event) => {
      const { contact } = this.state;
      const newContact = {
        ...contact,
        [propertyName]: event.target.value
      };
     this.setState({ contact: newContact });
}

onSubmitHandler = (event) =>{
 event.preventDefault();
 const contact = this.state.contact
 console.log(contact);
 // sendind data to firebase
 // axios.post('https://contactapp-80ffa.firebaseio.com/contact',contact)
 //      .then(response =>{
 //        console.log(response);
 //      })
}

  render(){
    return(
  <section id="contact">
      <div className="container">
          <div className="well well-sm">
            <h3><strong>Contact Us</strong></h3>
          </div>
      	<div className="row">
        	   <div className="col-md-7">
                <iframe src="https://maps.google.com/maps?q=alexandria&t=&z=13&ie=UTF8&iwloc=&output=embed" title='map'></iframe>
              </div>
              <div className="col-md-5">
                  <h4><strong>Get in Touch</strong></h4>
                <form onSubmit={this.onSubmitHandler}>
                  <div className="form-group">
                    <input type="text" className="form-control" name="" value={this.state.contact.name} placeholder="Name" onChange={this.onChangeHandler('name')}/>
                  </div>
                  <div className="form-group">
                    <input type="email" className="form-control" name="" value={this.state.contact.email} placeholder="E-mail" onChange={this.onChangeHandler('email')}/>
                  </div>
                  <div className="form-group">
                    <input type="tel" className="form-control" name="" value={this.state.contact.phone} placeholder="Phone" onChange={this.onChangeHandler('phone')}/>
                  </div>
                  <div className="form-group">
                    <textarea className="form-control" name="" rows="3" value={this.state.contact.message} placeholder="Message" onChange={this.onChangeHandler('message')}></textarea>
                  </div>
                  <button className="btn btn-default" type="submit" name="button">
                      <i className="fa fa-paper-plane-o" aria-hidden="true"></i> Submit
                  </button>
                </form>
              </div>
          </div>
      </div>
  </section>
    )
  }
}

export default ContactForm;
